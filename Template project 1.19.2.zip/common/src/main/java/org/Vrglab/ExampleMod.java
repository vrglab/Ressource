package org.Vrglab;

public final class ExampleMod {
    public static final String MOD_ID = "template";

    public static void init() {
        // Write common init code here.
    }
}
